---
title: "Continue"
description: "Your documentation starts here."
---

# Continue (Continuar)

Pula a iteração atual e avança para a próxima.

# Exemplo: 

para (inteiro i = 1; i <= 10; incremente i) {
    se (i % 2 == 0) {
        continuar;  // pula os números pares
    }
    imprima i;  // imprime apenas ímpares
}

