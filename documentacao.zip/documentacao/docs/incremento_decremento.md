---
title: "Incremento/Decremento"
description: "Your documentation starts here."
---

# Incremento/Decremento

Servem para aumentar ou diminuir o valor de uma variável numérica.

| Tipo  | Descrição |
| ------------- |:-------------:|
| ++  | Incremento (pré e pós)     |
| --     | Decremento (pré e pós) |

