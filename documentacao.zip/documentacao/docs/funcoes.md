---
title: "Funções"
---
<br>

# O que são Funções?
**Funções** são blocos de código que executam uma tarefa específica. Elas são essenciais para organizar e reutilizar o código, permitindo que você chame uma ação ou obtenha um valor de forma simples, sem precisar reescrever o mesmo código várias vezes.
Em LiPo, as funções podem ser declaradas com ou sem um valor de retorno, e podem aceitar diferentes tipos de dados como parâmetros.

<br>
