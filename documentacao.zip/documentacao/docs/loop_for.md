---
title: "Loop For"
description: "Your documentation starts here."
---

# Loop For (para) tradicional 

Executa um bloco de código com uma variável de controle.

# Exemplo: 

para i = 1 ate 10 faca {
    imprima i;
}

//Imprime de 1 a 10.






