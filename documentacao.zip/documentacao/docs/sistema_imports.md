---
title: "Sistema de importe "
---

# Sistema de imports

O sistema de importação da linguagem LiPo permite incluir bibliotecas externas para ampliar as funcionalidades do programa, como operações matemáticas, manipulação de texto, entrada/saída e controle de datas.

