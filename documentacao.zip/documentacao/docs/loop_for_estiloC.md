---
title: "Loop For Estilo C"
description: "Your documentation starts here."
---

# Loop For (para) Estilo C:

A estrutura para no estilo C permite controle total da repetição, com inicialização, condição e incremento definidos explicitamente.


# Exemplo:

para (inteiro i = 0; i < 10; i = i + 1) {
    imprima i;
}




