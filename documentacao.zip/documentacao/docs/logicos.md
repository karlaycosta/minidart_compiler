---
title: "Lógicos"
description: "Your documentation starts here."
---

# Lógicos

São utilizados para construir expressões condicionais mais complexas, combinando múltiplas comparações.

# Operadores:

* e (&&) = AND

* ou (||) = OR

* ! = NOT


# Descrição: 

* e (&&) = Retorna true se ambas as condições forem verdadeiras

* ou (||) = Retorna true se pelo menos uma condição for verdadeira

* ! = Inverte o resultado lógico da condição


