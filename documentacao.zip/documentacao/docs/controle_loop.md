---
title: "Controle de Loop"
description: "Your documentation starts here."
---

# Controle de Loop

Um controle de loop é uma estrutura usada em linguagens de programação (como Portugol, Java, Python etc.) para repetir um bloco de código várias vezes, de forma automática e controlada por uma condição.






