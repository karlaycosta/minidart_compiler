---
title: "Gramática Formal"
---

<br>

A linguagem LiPo possui uma gramática semelhante a gramáticas livres de contexto (CFG). Cada produção define como uma estrutura válida do programa deve ser escrita.

