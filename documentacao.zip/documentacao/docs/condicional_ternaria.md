---
title: "Condicional Ternária"
description: "Your documentation starts here."
---

# Condicional Ternária

Usa o operador ? : para avaliar uma condição e retornar um valor rapidamente.

# Exemplo:

var status = idade >= 18 ? "adulto" : "jovem";
//A variável status recebe "adulto" se idade >= 18; caso contrário, recebe "jovem".



