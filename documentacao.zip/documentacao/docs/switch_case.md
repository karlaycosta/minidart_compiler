---
title: "Switch/Case"
description: "Your documentation starts here."
---

# Switch/Case (escolha/caso):

A estrutura é usada para executar diferentes blocos de código com base no valor de uma expressão.


# Exemplo:

inteiro dia = 3;

escolha (dia) {
    
    caso 1:
        imprima "Segunda-feira";
        parar;

    caso 2:
        imprima "Terça-feira";
        parar;

    caso 3:
        imprima "Quarta-feira";
        parar;

    contrario:
        imprima "Outro dia";
}




