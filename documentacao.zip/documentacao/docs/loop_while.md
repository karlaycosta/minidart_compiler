---
title: "Loop While"
description: "Your documentation starts here."
---

# Loop While (enquanto):

Executa repetidamente enquanto a condição for verdadeira.

# Exemplo: 

var contador = 1;
enquanto (contador <= 5) {
    imprima contador;
    contador = contador + 1;
}

//Imprime os números de 1 a 5. A condição é avaliada antes de cada execução.






