---
title: "Loop For Incremento"
description: "Your documentation starts here."
---

# Loop For (para) com Incremento

Permite avançar com passos personalizados.

# Exemplo:

para i = 0 ate 20 incremente 2 faca {
    imprima i;
}

//Imprime apenas os números pares entre 0 e 20.




