---
title: "Sobre  "
---

# Sobre

Este projeto **LiPo Docs** tem como objetivo documentar o compilador LiPo, fornecendo informações detalhadas sobre a linguagem, exemplos de uso, operadores, estruturas de controle e muito mais.

O site é mantido por:

- Deriks Karlay Dias Costa  
- Aline Cély Araújo Da Silva  
- Filipe da Silva Paiva  
- Igor Wenceslau Machado Conceição  
- Italo Araujo de Assunção  
- Jhonefer Vinicius Lima da Silva  
- João Gabriel Peres de Castro  
- João Pedro Sousa Cavalcante  
- João Vitor de Almeida Freitas  
- Leonardo Guile Freitas do Nascimento  
- Luiz Eduardo Barbosa França  
- Noan Moreira Da Costa  
- Pedro Gabriel Modesto Caddah  
- Stella Karolina Nunes Peixoto  
- Thaís Santos de Oliveira  
- Vitor Galvão Mezzomo  

## Objetivo

Prover documentação clara e acessível para desenvolvedores e estudantes, permitindo aprendizado rápido e referência prática.
