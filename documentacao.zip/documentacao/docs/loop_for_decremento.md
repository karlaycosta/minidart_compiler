---
title: "Loop For Decremento"
description: "Your documentation starts here."
---

# Loop For (para) com Decremento

Permite percorrer valores decrescentes.

# Exemplo:

para i = 10 ate 0 decremente 2 faca {
    imprima i;
}

//Imprime de 10 a 0 em passos de 2, útil para contagens regressivas.





