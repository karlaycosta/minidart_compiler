---
title: "Condicional"
description: "Your documentation starts here."
---

# Condicional: se / senao (If/else)

Permite executar blocos de código diferentes de acordo com o resultado de uma expressão booleana.

# Exemplo:

se (idade >= 18) {
    imprima "Maior de idade";
} senao {
    imprima "Menor de idade";
}

//Verifica se idade é maior ou igual a 18. Se sim, imprime uma mensagem; se não, imprime outra.

