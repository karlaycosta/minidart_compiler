#!/bin/bash
# ─────────────────────────────────────────────────────────────
#  LiPo Deploy v3.5 - Deploy Automático para Netlify
#  Autor: Stella ❤️
#  Data: 2023-10-01
#  Descrição: Monitoramento e deploy automático com painel limpo
# ─────────────────────────────────────────────────────────────

# ---------------- CONFIGURAÇÃO ----------------
SITE_DIR="../site"
CHECKSUM_FILE=".deploy_checksums"
CHECK_INTERVAL=7200   # 120 minutos em segundos
SITE_ID="8ba5630d-2544-4805-b0a1-38fcd5b83dbf"
LOG_FILE="deploy.log"

# ---------------- VARIÁVEIS ----------------
success=0
fail=0

# ---------------- FUNÇÕES ----------------
banner() {
    echo "╭──────────────────────────────────────────────╮"
    echo "│        LiPo Deploy - Deploy Automático       │"
    echo "╰──────────────────────────────────────────────╯"
}

show_stats() {
    local total=$((success + fail))
    local rate=0
    if [[ $total -gt 0 ]]; then
        rate=$(( (success * 100) / total ))
    fi

    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    printf "Total Deploys : %d\n" "$total"
    printf "Com Sucesso   : %d\n" "$success"
    printf "Falhas        : %d\n" "$fail"
    printf "Taxa Sucesso  : %d%%\n" "$rate"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

log_event() {
    local status="$1"
    local message="$2"
    local timestamp
    timestamp=$(date "+[%d/%m/%Y %H:%M:%S]")
    echo "${timestamp} (Desconhecido) STATUS: ${status} - ${message}" >> "$LOG_FILE"
}

check_changes() {
    local temp_file
    temp_file=$(mktemp)
    find "$SITE_DIR" -type f -exec sha1sum {} \; | sort > "$temp_file"

    if [[ -f "$CHECKSUM_FILE" ]]; then
        sort "$CHECKSUM_FILE" -o "$CHECKSUM_FILE"
        local changed
        local removed
        changed=$(comm -13 "$CHECKSUM_FILE" "$temp_file" | wc -l)
        removed=$(comm -23 "$CHECKSUM_FILE" "$temp_file" | wc -l)
        mv "$temp_file" "$CHECKSUM_FILE"

        if [[ $changed -gt 0 || $removed -gt 0 ]]; then
            echo "$changed|$removed"
        else
            echo "no"
        fi
    else
        mv "$temp_file" "$CHECKSUM_FILE"
        echo "first"
    fi
}

deploy_site() {
    if [[ ! -d "$SITE_DIR" ]]; then
        log_event "FALHA" "Deploy falhou: pasta '${SITE_DIR}' não encontrada"
        ((fail++))
        return 1
    fi

    output=$(netlify deploy --prod --site="$SITE_ID" --dir="$SITE_DIR" --no-build 2>&1)
    if [[ $? -eq 0 ]]; then
        ((success++))
        log_event "SUCESSO" "Deploy OK - URL: https://documentacao-lipo.netlify.app"
    else
        ((fail++))
        log_event "FALHA" "Build falhou: ${output}"
    fi
}

progress_bar() {
    local duration=$1
    local elapsed=0
    local bar_length=40

    while [ $elapsed -lt $duration ]; do
        local filled=$(( (elapsed * bar_length) / duration ))
        local percent=$(( (elapsed * 100) / duration ))
        local remaining=$((duration - elapsed))

        # Formata o tempo restante em hh:mm:ss
        local hrs=$((remaining / 3600))
        local mins=$(( (remaining % 3600) / 60 ))
        local secs=$((remaining % 60))
        local time_left=$(printf "%02d:%02d:%02d" "$hrs" "$mins" "$secs")

        # Atualiza em tempo real
        printf "\rProgresso: [%-${bar_length}s] %3d%% | Restante: %s" \
            "$(printf "%0.s#" $(seq 1 $filled))" "$percent" "$time_left"

        sleep 1
        ((elapsed++))
    done
    echo ""
}


trap "log_event 'PARADO' 'Encerrado manualmente'; clear; echo 'Monitoramento encerrado.'; exit 0" SIGINT

main_loop() {
    while true; do
        clear
        banner

        result=$(check_changes)
        case "$result" in
            no)
                ;;
            first)
                deploy_site
                ;;
            *)
                deploy_site
                ;;
        esac

        show_stats
        next_time=$(date -d "+$CHECK_INTERVAL seconds" "+%H:%M:%S")
        echo "Próxima verificação às $next_time (em $((CHECK_INTERVAL/60)) minutos)..."
        echo ""
        progress_bar $CHECK_INTERVAL
    done
}

main_loop
